mCider Themes
=============

Slide show theme of mCider.

## Installation

```
$ git clone https://github.com/ogom/mcider-themes.git
```

## Uses

* [HTML5 slide template for Google I/O 2012](http://code.google.com/p/io-2012-slides/)
* [HTML5 slide template for Google I/O 2011](http://code.google.com/p/html5slides/)

## Licence

* MIT
